// Run after "npx cap add android": landscape orientation + immersive fullscreen + keep screen on.
import { readFileSync, writeFileSync, existsSync, cpSync, mkdirSync } from 'node:fs';
const manifest = 'android/app/src/main/AndroidManifest.xml';
if (!existsSync(manifest)) { console.error('android/ folder not found. Run "npx cap add android" first.'); process.exit(1); }
let m = readFileSync(manifest, 'utf8');
if (!m.includes('screenOrientation')) m = m.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
writeFileSync(manifest, m);

const java = 'android/app/src/main/java/com/mansports/app/MainActivity.java';
writeFileSync(java, `package com.mansports.app;

import android.os.Bundle;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    private void hideBars() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat c = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        c.hide(WindowInsetsCompat.Type.systemBars());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }
}
`);
console.log('Android project patched.');

// MAN SPORTS icon: copy launcher icons over the Capacitor defaults + set adaptive-icon background colour.
cpSync('branding/res', 'android/app/src/main/res', { recursive: true });
mkdirSync('android/app/src/main/res/values', { recursive: true });
writeFileSync('android/app/src/main/res/values/ic_launcher_background.xml',
`<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#06130D</color>
</resources>
`);
console.log('MAN SPORTS icons installed.');
