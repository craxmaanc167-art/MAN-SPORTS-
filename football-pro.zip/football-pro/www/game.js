/* FOOTBALL 3D PRO — 11v11 football (Three.js). Fictional clubs, no licensed content. */
let THREE;
try { THREE = await import('./vendor/three.module.js'); }
catch (e) { THREE = await import('https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js'); }

/* ───────────────────────── helpers ───────────────────────── */
const $ = (s) => document.querySelector(s);
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = (arr) => arr[(Math.random() * arr.length) | 0];
const wrap = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
const turnTo = (a, b, m) => a + clamp(wrap(b - a), -m, m);
const HL = 52.5, HW = 34, GW = 3.66, GH = 2.44, BOX_D = 16.5, BOX_W = 20.16;
const IS_TOUCH = (window.matchMedia && matchMedia('(pointer:coarse)').matches) || 'ontouchstart' in window;
const TEST = location.search.includes('test');

const TEAMS = [
  { name: 'Banaadir Stars', short: 'BAN', shirt: '#1e6fe0', shorts: '#ffffff', socks: '#1e6fe0', num: '#ffffff' },
  { name: 'Waqooyi Lions', short: 'WAQ', shirt: '#d92b2b', shorts: '#111111', socks: '#d92b2b', num: '#ffffff' },
  { name: 'Jubba Sharks', short: 'JUB', shirt: '#0fb5a6', shorts: '#0b3c5d', socks: '#0fb5a6', num: '#ffffff' },
  { name: 'Puntland Eagles', short: 'PUN', shirt: '#f2f2f2', shorts: '#0a7a3b', socks: '#0a7a3b', num: '#0a7a3b' },
  { name: 'Shabelle Kings', short: 'SHA', shirt: '#f4c20d', shorts: '#1b1b1b', socks: '#f4c20d', num: '#1b1b1b' },
  { name: 'Galmudug Falcons', short: 'GAL', shirt: '#7b2cbf', shorts: '#ffffff', socks: '#7b2cbf', num: '#ffffff' },
];
const FORMATION = [ // role, base x, base depth (0 own goal → 1 opp goal)
  ['GK', 0, 0.02],
  ['DEF', -22, 0.2], ['DEF', -8, 0.17], ['DEF', 8, 0.17], ['DEF', 22, 0.2],
  ['MID', -24, 0.45], ['MID', -8, 0.42], ['MID', 8, 0.42], ['MID', 24, 0.45],
  ['FWD', -9, 0.68], ['FWD', 9, 0.68],
];
const NUMBERS = [1, 2, 4, 5, 3, 7, 8, 6, 11, 9, 10];
const DIFF = [
  { aiSpeed: 0.88, react: 0.7, err: 1.6, gk: 0.58, tackle: 0.35 },
  { aiSpeed: 0.95, react: 0.5, err: 1.15, gk: 0.74, tackle: 0.6 },
  { aiSpeed: 1.0, react: 0.35, err: 0.8, gk: 0.86, tackle: 0.9 },
];

/* ───────────────────────── renderer / scene ───────────────────────── */
const canvas = $('#game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: !IS_TOUCH, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, IS_TOUCH ? 1.5 : 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
const SHADOWS = !IS_TOUCH;
renderer.shadowMap.enabled = SHADOWS;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(42, 1, 0.5, 600);

function canvasTex(w, h, draw, srgb = true) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
const matCache = {};
const M = (color, rough = 0.8, extra) => {
  const k = color + '|' + rough + (extra ? JSON.stringify(extra) : '');
  return matCache[k] || (matCache[k] = new THREE.MeshStandardMaterial({ color, roughness: rough, ...(extra || {}) }));
};

function buildWorld() {
  // sky
  scene.background = canvasTex(8, 256, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#3f7fc4'); g.addColorStop(0.55, '#9cc7ec'); g.addColorStop(1, '#dbe9f3');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
  });
  scene.fog = new THREE.Fog(0xb9d3e8, 120, 330);

  scene.add(new THREE.HemisphereLight(0xdff0ff, 0x3a5a33, 1.25));
  const sun = new THREE.DirectionalLight(0xfff1d6, 2.4);
  sun.position.set(-30, 60, 35);
  sun.castShadow = SHADOWS;
  sun.shadow.mapSize.set(2048, 2048);
  const sc = sun.shadow.camera; sc.left = -38; sc.right = 38; sc.top = 38; sc.bottom = -38; sc.near = 10; sc.far = 160;
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.03;
  scene.add(sun); scene.add(sun.target);
  world.sun = sun;

  // pitch
  const k = 1024 / 68;
  const X = (x) => (x + HW) * k, Z = (z) => (z + HL) * k;
  const pt = canvasTex(1024, 1580, (c, W, H) => {
    const n = 16;
    for (let i = 0; i < n; i++) { c.fillStyle = i % 2 ? '#2f9141' : '#2a8139'; c.fillRect(0, (i * H) / n, W, H / n + 1); }
    for (let i = 0; i < 9000; i++) {
      c.fillStyle = `rgba(${(Math.random() * 30) | 0},${(60 + Math.random() * 60) | 0},${(Math.random() * 30) | 0},.07)`;
      c.fillRect(Math.random() * W, Math.random() * H, 1 + Math.random() * 2, 2 + Math.random() * 5);
    }
    c.strokeStyle = '#f3f7f3'; c.lineWidth = 3.4; c.lineCap = 'round';
    const R = (x1, z1, x2, z2) => c.strokeRect(X(x1), Z(z1), X(x2) - X(x1), Z(z2) - Z(z1));
    R(-HW + 0.1, -HL + 0.1, HW - 0.1, HL - 0.1);
    c.beginPath(); c.moveTo(X(-HW), Z(0)); c.lineTo(X(HW), Z(0)); c.stroke();
    c.beginPath(); c.arc(X(0), Z(0), 9.15 * k, 0, 7); c.stroke();
    c.fillStyle = '#f3f7f3'; c.beginPath(); c.arc(X(0), Z(0), 0.3 * k, 0, 7); c.fill();
    const a = Math.acos((BOX_D - 11) / 9.15);
    for (const s of [-1, 1]) {
      const zl = s * HL, zi = s * (HL - BOX_D), zg = s * (HL - 5.5), zs = s * (HL - 11);
      R(-BOX_W, Math.min(zl, zi), BOX_W, Math.max(zl, zi));
      R(-9.16, Math.min(zl, zg), 9.16, Math.max(zl, zg));
      c.beginPath(); c.arc(X(0), Z(zs), 0.3 * k, 0, 7); c.fill();
      c.beginPath();
      if (s < 0) c.arc(X(0), Z(zs), 9.15 * k, Math.PI / 2 - a, Math.PI / 2 + a);
      else c.arc(X(0), Z(zs), 9.15 * k, -Math.PI / 2 - a, -Math.PI / 2 + a);
      c.stroke();
    }
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      c.beginPath();
      const cx = X(sx * HW), cz = Z(sz * HL);
      const st = sx < 0 ? (sz < 0 ? 0 : -Math.PI / 2) : (sz < 0 ? Math.PI / 2 : Math.PI);
      c.arc(cx, cz, k, st, st + Math.PI / 2); c.stroke();
    }
  });
  const pitch = new THREE.Mesh(new THREE.PlaneGeometry(68, 105), new THREE.MeshStandardMaterial({ map: pt, roughness: 0.95 }));
  pitch.rotation.x = -Math.PI / 2; pitch.receiveShadow = true; scene.add(pitch);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(500, 500), M('#25602f', 1));
  ground.rotation.x = -Math.PI / 2; ground.position.y = -0.03; ground.receiveShadow = true; scene.add(ground);

  // goals
  const netTex = canvasTex(64, 64, (c) => {
    c.clearRect(0, 0, 64, 64); c.strokeStyle = 'rgba(255,255,255,.9)'; c.lineWidth = 3;
    c.strokeRect(0, 0, 64, 64);
  });
  netTex.wrapS = netTex.wrapT = THREE.RepeatWrapping;
  const netMat = new THREE.MeshBasicMaterial({ map: netTex, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false });
  const frameMat = M('#f4f4f4', 0.4, { metalness: 0.1 });
  for (const sz of [-1, 1]) {
    const g = new THREE.Group(); const D = 2.4;
    const post = (x) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, GH, 10), frameMat); m.position.set(x, GH / 2, 0); m.castShadow = SHADOWS; g.add(m); };
    post(-GW); post(GW);
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, GW * 2, 10), frameMat); bar.rotation.z = Math.PI / 2; bar.position.y = GH; bar.castShadow = SHADOWS; g.add(bar);
    const mk = (w, h, rx, ry, x, y, z, rw, rh) => {
      const t = netTex.clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rw, rh);
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false }));
      m.rotation.x = rx; m.rotation.y = ry; m.position.set(x, y, z); g.add(m);
    };
    mk(GW * 2, GH, 0, 0, 0, GH / 2, D, 30, 10);
    mk(D, GH, 0, Math.PI / 2, -GW, GH / 2, D / 2, 10, 10); mk(D, GH, 0, Math.PI / 2, GW, GH / 2, D / 2, 10, 10);
    mk(GW * 2, D, -Math.PI / 2, 0, 0, GH, D / 2, 30, 10);
    for (const x of [-GW, GW]) {
      const bp = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, GH, 6), frameMat); bp.position.set(x, GH / 2, D); g.add(bp);
    }
    g.position.z = sz * HL; if (sz < 0) g.rotation.y = Math.PI;
    scene.add(g);
  }
  // corner flags
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.5, 6), M('#ffffff'));
    pole.position.set(sx * HW, 0.75, sz * HL); scene.add(pole);
    const fl = new THREE.Mesh(new THREE.PlaneGeometry(0.35, 0.25), new THREE.MeshBasicMaterial({ color: 0xffd400, side: THREE.DoubleSide }));
    fl.position.set(sx * HW + 0.18, 1.35, sz * HL); scene.add(fl);
  }
  // ad boards
  const adTex = canvasTex(1024, 64, (c, w, h) => {
    const names = ['FOOTBALL 3D', 'SUPER LEAGUE', 'KUBAD', 'CHAMPIONS', 'GOOOL!', 'PRO CUP'];
    const cols = ['#c8102e', '#0b3d91', '#0a8a43', '#f59e0b', '#6d28d9', '#0e7490'];
    const cw = w / names.length;
    names.forEach((n, i) => { c.fillStyle = cols[i]; c.fillRect(i * cw, 0, cw, h); c.fillStyle = '#fff'; c.font = '900 30px Arial'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(n, i * cw + cw / 2, h / 2 + 2); });
  });
  adTex.wrapS = THREE.RepeatWrapping;
  const adLong = adTex.clone(); adLong.needsUpdate = true; adLong.wrapS = THREE.RepeatWrapping; adLong.repeat.set(2.5, 1);
  const adMat1 = new THREE.MeshStandardMaterial({ map: adLong, roughness: 0.5, emissive: 0x222222 });
  const adShort = adTex.clone(); adShort.needsUpdate = true; adShort.wrapS = THREE.RepeatWrapping; adShort.repeat.set(2, 1);
  const adMat2 = new THREE.MeshStandardMaterial({ map: adShort, roughness: 0.5, emissive: 0x222222 });
  for (const sx of [-1, 1]) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.95, 110), adMat1); b.position.set(sx * (HW + 4), 0.48, 0); scene.add(b); }
  for (const sz of [-1, 1]) { const b = new THREE.Mesh(new THREE.BoxGeometry(76, 0.95, 0.3), adMat2); b.position.set(0, 0.48, sz * (HL + 5)); scene.add(b); }

  // stands + crowd
  const crowdTex = canvasTex(512, 128, (c, w, h) => {
    c.fillStyle = '#3a4350'; c.fillRect(0, 0, w, h);
    const cols = ['#d33', '#36c', '#eee', '#fc3', '#2a6', '#f80', '#222', '#a4a', '#5cf'];
    for (let y = 4; y < h; y += 8) for (let x = 2; x < w; x += 7) {
      c.fillStyle = pick(cols); c.fillRect(x + rnd(-1, 1), y, 4, 4);
      c.fillStyle = '#e9c9a4'; c.fillRect(x + 1 + rnd(-1, 1), y - 3, 2, 2);
    }
  });
  crowdTex.wrapS = crowdTex.wrapT = THREE.RepeatWrapping;
  const mkStand = (len, sideX, sideZ) => {
    const t = crowdTex.clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(len / 30, 1);
    const mat = new THREE.MeshStandardMaterial({ map: t, roughness: 1 });
    const concrete = M('#59626e', 1);
    for (let i = 0; i < 9; i++) {
      const h = 2.5 + i * 1.7, dpt = 2.6;
      const geo = new THREE.BoxGeometry(sideX ? dpt : len, h, sideX ? len : dpt);
      const m = new THREE.Mesh(geo, [mat, mat, concrete, concrete, mat, mat]);
      const off = i * dpt;
      if (sideX) m.position.set(sideX * (HW + 7 + off), h / 2, 0); else m.position.set(0, h / 2, sideZ * (HL + 8.5 + off));
      scene.add(m);
    }
  };
  mkStand(126, -1, 0); mkStand(126, 1, 0); mkStand(84, 0, -1); mkStand(84, 0, 1);
  // roof + light towers
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const px = sx * (HW + 22), pz = sz * (HL + 20);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.8, 38, 8), M('#8a929c', 0.6)); pole.position.set(px, 19, pz); scene.add(pole);
    const head = new THREE.Mesh(new THREE.BoxGeometry(7, 4, 0.8), new THREE.MeshStandardMaterial({ color: 0x222222, emissive: 0xfff2c8, emissiveIntensity: 1.8 }));
    head.position.set(px, 39, pz); head.lookAt(0, 20, 0); scene.add(head);
  }
}

/* ───────────────────────── game state ───────────────────────── */
const world = {};
const S = { mode: 'menu', state: 'restart', diff: 1, halfLen: 180, half: 1, time: 0, t: 0, homeDir: -1, charge: 0, restart: null, goalT: 0, scorer: null, msgT: 0, hudT: 0, miniT: 0 };
const ball = { x: 0, y: 0.11, z: 0, vx: 0, vy: 0, vz: 0, r: 0.11, owner: null, last: null, spin: 0, shot: 0, inNet: false, mesh: null, shadow: null };
const T = []; let ALL = [];
const inp = { x: 0, y: 0, sprint: false, passP: false, lobP: false, shootHeld: false, shootP: false, shootR: false, prevShoot: false };
const cam = { fx: 0, fz: 0, ox: 0, oz: 0, orbit: 0 };

/* ───────────────────────── audio ───────────────────────── */
let AC = null, crowd = null;
function audioInit() {
  if (AC) { if (AC.state === 'suspended') AC.resume(); return; }
  try {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    const len = AC.sampleRate * 3, buf = AC.createBuffer(1, len, AC.sampleRate), d = buf.getChannelData(0);
    let b = 0; for (let i = 0; i < len; i++) { b = 0.985 * b + 0.015 * (Math.random() * 2 - 1); d[i] = b * 9; }
    const src = AC.createBufferSource(); src.buffer = buf; src.loop = true;
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1100;
    crowd = AC.createGain(); crowd.gain.value = 0.12;
    src.connect(f); f.connect(crowd); crowd.connect(AC.destination); src.start();
  } catch (e) { AC = null; }
}
function sfxKick(p = 0.6) {
  if (!AC) return;
  try {
    const t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain();
    o.type = 'sine'; o.frequency.setValueAtTime(170 + p * 40, t); o.frequency.exponentialRampToValueAtTime(55, t + 0.12);
    g.gain.setValueAtTime(0.35 + p * 0.35, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + 0.16);
  } catch (e) { /* ignore */ }
}
function sfxWhistle(long) {
  if (!AC) return;
  try {
    const t = AC.currentTime, o = AC.createOscillator(), l = AC.createOscillator(), lg = AC.createGain(), g = AC.createGain();
    o.type = 'sine'; o.frequency.value = 2850; l.frequency.value = 34; lg.gain.value = 60;
    l.connect(lg); lg.connect(o.frequency);
    const dur = long ? 1.1 : 0.45;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.18, t + 0.03); g.gain.setValueAtTime(0.18, t + dur - 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(AC.destination); o.start(t); l.start(t); o.stop(t + dur); l.stop(t + dur);
  } catch (e) { /* ignore */ }
}
function sfxRoar() {
  if (!crowd || !AC) return;
  try { const t = AC.currentTime; crowd.gain.cancelScheduledValues(t); crowd.gain.setTargetAtTime(0.6, t, 0.15); crowd.gain.setTargetAtTime(0.14, t + 3.2, 1.2); } catch (e) { /* ignore */ }
}

/* ───────────────────────── player models ───────────────────────── */
const G = {};
function initGeos() {
  G.torso = new THREE.CylinderGeometry(0.21, 0.17, 0.62, 12);
  G.hip = new THREE.CylinderGeometry(0.18, 0.19, 0.3, 12);
  G.head = new THREE.SphereGeometry(0.115, 14, 12);
  G.hair = new THREE.SphereGeometry(0.122, 12, 8, 0, Math.PI * 2, 0, Math.PI / 1.9);
  G.thigh = new THREE.CapsuleGeometry(0.078, 0.3, 4, 8);
  G.shin = new THREE.CapsuleGeometry(0.06, 0.28, 4, 8);
  G.boot = new THREE.BoxGeometry(0.1, 0.07, 0.26);
  G.sleeve = new THREE.CapsuleGeometry(0.052, 0.2, 4, 8);
  G.fore = new THREE.CapsuleGeometry(0.042, 0.2, 4, 8);
  G.num = new THREE.PlaneGeometry(0.3, 0.3);
  G.blob = new THREE.CircleGeometry(0.7, 20);
  G.ring = new THREE.RingGeometry(0.62, 0.78, 36);
  G.arrow = new THREE.ConeGeometry(0.18, 0.4, 4);
  blobMat = new THREE.MeshBasicMaterial({ map: canvasTex(64, 64, (c) => { const g = c.createRadialGradient(32, 32, 2, 32, 32, 30); g.addColorStop(0, 'rgba(0,0,0,.55)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, 64, 64); }), transparent: true, depthWrite: false });
}
let blobMat;
const numTexCache = {};
function numTex(n, color) {
  const k = n + color;
  return numTexCache[k] || (numTexCache[k] = canvasTex(64, 64, (c) => { c.clearRect(0, 0, 64, 64); c.fillStyle = color; c.font = '900 50px Arial'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(String(n), 32, 36); }));
}
const SKINS = ['#f1c6a0', '#d9a066', '#b97a4b', '#8d5524', '#5a3825', '#3b2417'];
const HAIRS = ['#111111', '#1b1209', '#3b2a1a', '#0a0a0a', '#6b4a2b'];

function buildPlayerMesh(team, num, gk) {
  const shirt = gk ? '#2bd36b' : team.shirt, shorts = gk ? '#161616' : team.shorts, socks = gk ? '#161616' : team.socks;
  const g = new THREE.Group(), rig = new THREE.Group(); g.add(rig);
  const skin = pick(SKINS), hairC = pick(HAIRS);
  const add = (geo, mat, x, y, z, parent = rig) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = SHADOWS; parent.add(m); return m; };
  const torso = add(G.torso, M(shirt, 0.65), 0, 1.3, 0); torso.scale.z = 0.66;
  const hip = add(G.hip, M(shorts, 0.8), 0, 0.92, 0); hip.scale.z = 0.7;
  add(G.head, M(skin, 0.55), 0, 1.78, 0.005);
  add(G.hair, M(hairC, 0.9), 0, 1.79, -0.005);
  const leg = (x) => {
    const l = new THREE.Group(); l.position.set(x, 0.95, 0); rig.add(l);
    add(G.thigh, M(skin, 0.6), 0, -0.25, 0, l);
    add(G.shin, M(socks, 0.8), 0, -0.66, 0, l);
    add(G.boot, M(gk ? '#f2f2f2' : '#101010', 0.4), 0, -0.9, 0.05, l);
    return l;
  };
  const legL = leg(-0.1), legR = leg(0.1);
  const arm = (x) => {
    const a = new THREE.Group(); a.position.set(x, 1.53, 0); rig.add(a);
    add(G.sleeve, M(gk ? '#2bd36b' : shirt, 0.7), 0, -0.17, 0, a);
    add(G.fore, M(skin, 0.6), 0, -0.42, 0, a);
    return a;
  };
  const armL = arm(-0.27), armR = arm(0.27);
  const nm = new THREE.Mesh(G.num, new THREE.MeshBasicMaterial({ map: numTex(num, gk ? '#ffffff' : team.num), transparent: true, depthWrite: false }));
  nm.position.set(0, 1.34, -0.138); nm.rotation.y = Math.PI; rig.add(nm);
  const sc = rnd(0.96, 1.05); g.scale.setScalar(sc);
  return { g, rig, legL, legR, armL, armR };
}

function clearTeams() {
  for (const p of ALL) { scene.remove(p.mesh); scene.remove(p.blob); }
  ALL = []; T.length = 0;
  if (world.ring) { scene.remove(world.ring); scene.remove(world.arrow); }
}
function buildTeams(hi, ai) {
  clearTeams();
  const hk = TEAMS[hi], ak = TEAMS[ai];
  const clash = hi === ai;
  const akit = clash ? { ...ak, shirt: ak.shorts === '#ffffff' ? '#222222' : '#ffffff', shorts: ak.shirt, socks: ak.shirt, num: ak.shorts === '#ffffff' ? '#ffffff' : '#111111' } : ak;
  const kits = [hk, akit];
  for (let ti = 0; ti < 2; ti++) {
    const t = { id: ti, kit: kits[ti], dir: ti === 0 ? -1 : 1, players: [], score: 0, human: false, ctrl: null, lock: 0, hasBall: false, chaser: null, chaser2: null, opp: null, ...DIFF[1] };
    T.push(t);
  }
  T[0].opp = T[1]; T[1].opp = T[0];
  for (const t of T) {
    FORMATION.forEach(([role, bx, bd], idx) => {
      const parts = buildPlayerMesh(t.kit, NUMBERS[idx], role === 'GK');
      scene.add(parts.g);
      const blob = new THREE.Mesh(G.blob, blobMat); blob.rotation.x = -Math.PI / 2; blob.position.y = 0.02; blob.visible = !SHADOWS; scene.add(blob);
      const p = {
        team: t, idx, role, bx, bd, x: 0, z: 0, vx: 0, vz: 0, face: t.dir > 0 ? Math.PI : 0, phase: rnd(0, 6),
        stam: 100, pace: rnd(0.94, 1.06), skill: rnd(0.4, 0.9), kickCd: 0, stun: 0, tackleCd: 0, tackleAnim: 0, tackleDone: true, kickAnim: 0, header: 0,
        think: rnd(0, 0.4), hold: 0, dive: 0, diveAmt: 0, checkedShot: -1, celebrate: 0, mesh: parts.g, blob, parts,
      };
      t.players.push(p); ALL.push(p);
    });
  }
  // indicators
  world.ring = new THREE.Mesh(G.ring, new THREE.MeshBasicMaterial({ color: 0xffd24a, transparent: true, opacity: 0.9, depthWrite: false }));
  world.ring.rotation.x = -Math.PI / 2; world.ring.position.y = 0.03; scene.add(world.ring);
  world.arrow = new THREE.Mesh(G.arrow, new THREE.MeshBasicMaterial({ color: 0xffd24a }));
  world.arrow.rotation.x = Math.PI; scene.add(world.arrow);
  applyDiff();
}
function applyDiff() {
  const d = DIFF[S.diff];
  Object.assign(T[1], d);
  Object.assign(T[0], { aiSpeed: 0.95, react: 0.5, err: 1.15, gk: 0.76, tackle: 0.6 });
}

/* ───────────────────────── ball ───────────────────────── */
function buildBall() {
  const bt = canvasTex(256, 128, (c, w, h) => {
    c.fillStyle = '#f7f7f7'; c.fillRect(0, 0, w, h); c.fillStyle = '#1a1a1a';
    for (let i = 0; i < 14; i++) { const x = (i * w) / 14 + 8, y = h / 2 + Math.sin(i * 1.9) * 38; c.beginPath(); for (let k = 0; k < 5; k++) { const a = (k / 5) * 6.283 + i; c.lineTo(x + Math.cos(a) * 11, y + Math.sin(a) * 11); } c.closePath(); c.fill(); }
  });
  ball.mesh = new THREE.Mesh(new THREE.SphereGeometry(ball.r, 20, 14), new THREE.MeshStandardMaterial({ map: bt, roughness: 0.45 }));
  ball.mesh.castShadow = SHADOWS; scene.add(ball.mesh);
  ball.shadow = new THREE.Mesh(new THREE.CircleGeometry(0.3, 14), blobMat); ball.shadow.rotation.x = -Math.PI / 2; ball.shadow.position.y = 0.025; scene.add(ball.shadow);
}

/* ───────────────────────── queries ───────────────────────── */
const dist = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
function nearestOppDist(q) { let d = 1e9; for (const o of q.team.opp.players) { const k = Math.hypot(o.x - q.x, o.z - q.z); if (k < d) d = k; } return d; }
function laneBlocked(a, b) {
  const dx = b.x - a.x, dz = b.z - a.z, L2 = dx * dx + dz * dz || 1;
  for (const o of a.team.opp.players) {
    const t = ((o.x - a.x) * dx + (o.z - a.z) * dz) / L2; if (t < 0.1 || t > 0.95) continue;
    if (Math.hypot(o.x - (a.x + dx * t), o.z - (a.z + dz * t)) < 1.9) return true;
  }
  return false;
}
function homePos(p) {
  const t = p.team;
  const bd = (ball.z * t.dir + HL) / 105;
  if (p.role === 'GK') return { x: 0, z: -t.dir * HL + t.dir * 1.2 };
  const f = { DEF: 0.55, MID: 0.9, FWD: 0.8 }[p.role];
  let d = p.bd + (bd - 0.5) * f * 0.62;
  if (t.hasBall) d += p.role === 'FWD' ? 0.09 : p.role === 'MID' ? 0.05 : 0.02;
  d = clamp(d, p.role === 'DEF' ? 0.1 : 0.14, 0.96);
  const x = clamp(p.bx * 0.92 + ball.x * 0.28, -HW + 2, HW - 2);
  return { x, z: -t.dir * HL + t.dir * d * 105 };
}

/* ───────────────────────── ball actions ───────────────────────── */
function takeBall(p) {
  ball.owner = p; ball.last = p; ball.vx = p.vx; ball.vz = p.vz; ball.vy = 0; ball.spin = 0; ball.y = 0.11;
  p.hold = rnd(1.2, 2.2);
  if (S.state === 'restart') return;
}
function kick(p, dx, dz, speed, lift, spin = 0) {
  const L = Math.hypot(dx, dz) || 1; dx /= L; dz /= L;
  ball.owner = null; ball.vx = dx * speed; ball.vz = dz * speed; ball.vy = lift; ball.spin = spin; ball.last = p; ball.shot++;
  p.kickCd = 0.45; p.kickAnim = 0.3; p.face = Math.atan2(dx, dz);
  if (S.state === 'restart') { S.state = 'play'; S.restart = null; }
  sfxKick(speed / 30);
}
function bestPass(p, dx, dz, human) {
  let best = null, bs = -1e9;
  const restartType = S.restart && S.restart.type;
  for (const q of p.team.players) {
    if (q === p) continue;
    const ddx = q.x - p.x, ddz = q.z - p.z, d = Math.hypot(ddx, ddz);
    if (d < (restartType === 'throw' ? 3 : 4.5)) continue;
    let s;
    if (human) {
      const a = (ddx * dx + ddz * dz) / (d * (Math.hypot(dx, dz) || 1)); if (a < 0.6) continue;
      s = a * 10 - d * 0.08;
    } else {
      s = (q.z - p.z) * p.team.dir * 0.1 + Math.min(8, nearestOppDist(q)) * 0.45 - d * 0.05;
      if (q.role === 'GK') s -= restartType === 'goalkick' ? 99 : 6;
    }
    if (laneBlocked(p, q)) s -= human ? 2 : 5;
    if (d > 48) s -= 5;
    if (s > bs) { bs = s; best = q; }
  }
  return { q: best, score: bs };
}
function doPass(p, dx, dz, lob, human) {
  const r = bestPass(p, dx, dz, human);
  let tx, tz, d;
  if (r.q) {
    d = dist(p, r.q); const lead = d / 14;
    tx = r.q.x + r.q.vx * lead * 0.8; tz = r.q.z + r.q.vz * lead * 0.8;
  } else { const L = Math.hypot(dx, dz) || 1; tx = p.x + (dx / L) * 18; tz = p.z + (dz / L) * 18; }
  d = Math.hypot(tx - p.x, tz - p.z);
  let sp, lift = 0;
  if (lob) { sp = clamp(d * 0.75 + 4, 10, 26); lift = clamp(4.9 * (d / sp) * 1.05, 3, 14); }
  else sp = clamp(d * 0.7 + 6, 9, 28);
  const err = (0.025 + 0.03 * (sp / 28)) * (human ? 0.8 : p.team.err) * (1.4 - p.skill);
  const ang = Math.atan2(tx - p.x, tz - p.z) + rnd(-1, 1) * err;
  kick(p, Math.sin(ang), Math.cos(ang), sp, lift, 0);
  if (human && r.q) { p.team.ctrl = r.q; p.team.lock = 0.6; }
}
function doShoot(p, aimX, power) {
  const t = p.team, gz = t.dir * HL;
  const d = Math.hypot(p.x, gz - p.z);
  const err = (t.human && t.ctrl === p ? 0.8 : t.err) * (0.5 + d / 38) * (1.35 - p.skill) + (power > 0.92 ? 0.35 : 0);
  let tx = clamp(aimX, -1, 1) * (GW - 0.5) + rnd(-1, 1) * err * 1.7;
  const sp = 14 + power * 17;
  const T_ = Math.max(0.15, d / sp);
  let h = rnd(0.35, 1.7) + (power > 0.85 ? rnd(0, 1.2) : 0);
  if (Math.random() < err * 0.16) h = rnd(2.8, 4.5);
  const lift = clamp((h - 0.11 + 4.9 * T_ * T_) / T_, 0, 13);
  kick(p, tx - p.x, gz - p.z, sp, lift, rnd(-0.5, 0.5) * power);
}
function performTackle(p) {
  if (p.tackleCd > 0 || p.stun > 0) return;
  p.tackleAnim = 0.5; p.tackleCd = 1.4; p.tackleDone = false;
  p.vx += Math.sin(p.face) * 6.5; p.vz += Math.cos(p.face) * 6.5;
}
function resolveTackle(p) {
  const o = ball.owner;
  if (o && o.team !== p.team && Math.hypot(o.x - p.x, o.z - p.z) < 1.55) {
    p.tackleDone = true;
    const skill = 0.5 + (p.skill - 0.5) * 0.4 + (p.team.human && p.team.ctrl === p ? 0.05 : (p.team.tackle - 0.6) * 0.2);
    if (Math.random() < skill) {
      o.stun = 0.8; ball.owner = null; ball.last = p; ball.vx = Math.sin(p.face) * 5 + rnd(-2, 2); ball.vz = Math.cos(p.face) * 5 + rnd(-2, 2); ball.vy = rnd(0, 1.5); p.kickCd = 0;
      if (Math.random() < 0.45) takeBall(p);
      if (p.team.human && !ball.owner) p.team.lock = 0.2;
    } else if (Math.random() < 0.28) foul(p, o);
    else p.stun = 0.5;
  }
}
function foul(p, o) {
  banner('FOUL!', 1400); sfxWhistle(false);
  const t = o.team, inBox = t.dir * o.z > HL - BOX_D && Math.abs(o.x) < BOX_W;
  if (inBox) setupRestart('penalty', t, 0, t.dir * (HL - 11));
  else setupRestart('freekick', t, clamp(o.x, -HW + 1, HW - 1), clamp(o.z, -HL + 2, HL - 2));
}

/* ───────────────────────── restarts ───────────────────────── */
function setupRestart(type, team, x, z) {
  S.state = 'restart';
  const r = (S.restart = { type, team, x, z, timer: 0, taker: null });
  ball.owner = null; ball.vx = ball.vy = ball.vz = 0; ball.spin = 0; ball.inNet = false;
  const outf = team.players.filter((p) => p.role !== 'GK');
  let taker;
  if (type === 'goalkick') taker = team.players[0];
  else if (type === 'kickoff' || type === 'penalty') taker = team.players[9];
  else taker = outf.reduce((a, b) => (Math.hypot(a.x - x, a.z - z) < Math.hypot(b.x - x, b.z - z) ? a : b));
  r.taker = taker;
  if (type === 'kickoff') {
    x = r.x = 0; z = r.z = 0;
    for (const p of ALL) {
      const hp = homePos(p); const t = p.team;
      let d = clamp((hp.z * t.dir + HL) / 105, 0.02, 0.45);
      if (p.role === 'FWD') d = t === team ? 0.49 : 0.37;
      p.x = hp.x; p.z = -t.dir * HL + t.dir * d * 105; p.vx = p.vz = 0; p.stun = 0;
      if (p.role === 'FWD' && t === team) p.x = p.idx === 9 ? 0 : -6;
      if (p.role === 'FWD' && t !== team) p.x = p.idx === 9 ? -10 : 10;
      p.face = t.dir > 0 ? 0 : Math.PI; // facing the opponent goal
    }
    taker.x = 0; taker.z = -0.5 * team.dir;
  } else if (type === 'penalty') {
    const t = team, opp = team.opp;
    for (const p of ALL) {
      if (p === taker) continue;
      if (p.role === 'GK' && p.team === opp) { p.x = 0; p.z = -opp.dir * HL + opp.dir * 0.4; p.vx = p.vz = 0; continue; }
      const sx = ((p.idx * 7) % 11 - 5) * 3.4;
      p.x = clamp(sx, -HW + 2, HW - 2); p.z = t.dir * (HL - 22.5 - (p.idx % 3) * 1.2); p.vx = p.vz = 0;
    }
    taker.x = x; taker.z = z - team.dir * 2.2;
  } else {
    // push opponents back
    for (const o of team.opp.players) {
      if (type === 'throw') continue;
      if (type === 'goalkick' && o.role !== 'GK') {
        const gz = -team.dir * HL; // team's own goal z
        const depth = Math.abs(o.z - gz); if (depth < BOX_D + 1 && Math.abs(o.x) < BOX_W + 1) o.z = gz + Math.sign(o.z - gz || 1) * (BOX_D + 2);
        continue;
      }
      if (o.role === 'GK' && type !== 'freekick') continue;
      const d = Math.hypot(o.x - x, o.z - z);
      if (d < 9.5 && o.role !== 'GK') { const k = (9.8) / (d || 1); o.x = x + (o.x - x) * k || x + 9.8; o.z = z + (o.z - z) * k; }
    }
    taker.x = x + (type === 'throw' ? Math.sign(x) * 0.7 : -team.dir * 0.3 * 0); taker.z = z - (type === 'throw' ? 0 : team.dir * 0.9);
    taker.vx = taker.vz = 0;
  }
  taker.vx = taker.vz = 0;
  // face the play
  taker.face = type === 'throw' ? Math.atan2(-Math.sign(x), 0) : (team.dir > 0 ? 0 : Math.PI);
  ball.x = r.x; ball.z = r.z; ball.y = type === 'throw' ? 1.9 : 0.11;
  ball.owner = taker; ball.last = taker;
  for (const t of T) if (t.human) { t.ctrl = t === team ? taker : t.ctrl; t.lock = 0.4; }
  if (type !== 'kickoff') sfxWhistle(false);
}

function restartUpdate(dt) {
  const r = S.restart; if (!r) return; r.timer += dt;
  const t = r.team, tk = r.taker;
  if (t.human && S.mode === 'match') {
    // aim with stick
    const m = worldMove();
    if (Math.hypot(m.x, m.z) > 0.25 && r.type !== 'throw') tk.face = turnTo(tk.face, Math.atan2(m.x, m.z), 10 * dt);
    if (r.timer > 12) aiRestartAction(tk, r);
  } else if (r.timer > rnd(1.1, 1.8)) aiRestartAction(tk, r);
}
function aiRestartAction(p, r) {
  const t = p.team;
  if (r.type === 'penalty') { doShoot(p, rnd(-0.9, 0.9), rnd(0.65, 0.9)); return; }
  if (r.type === 'freekick') {
    const d = Math.hypot(p.x, t.dir * HL - p.z);
    if (d < 28 && Math.abs(p.x) < 22) { doShoot(p, rnd(-0.8, 0.8), rnd(0.6, 0.85)); return; }
    doPass(p, 0, t.dir, false, false); return;
  }
  if (r.type === 'corner') {
    const tx = rnd(-5, 5), tz = t.dir * (HL - 9);
    const sp = clamp(Math.hypot(tx - p.x, tz - p.z) * 0.8 + 4, 12, 26), d = Math.hypot(tx - p.x, tz - p.z);
    kick(p, tx - p.x, tz - p.z, sp, clamp(4.9 * (d / sp) * 1.05, 3, 14), rnd(-1, 1)); return;
  }
  if (r.type === 'goalkick') {
    const q = bestPass(p, 0, t.dir, false).q;
    if (q) { const d = dist(p, q), sp = clamp(d * 0.75 + 4, 12, 28); kick(p, q.x - p.x, q.z - p.z, sp, clamp(4.9 * (d / sp) * 1.05, 3, 14)); }
    else kick(p, rnd(-0.3, 0.3), t.dir, 24, 9);
    return;
  }
  doPass(p, 0, t.dir, false, false);
}

/* ───────────────────────── control / input ───────────────────────── */
function worldMove() { // screen stick → world
  const hd = S.homeDir;
  return { x: inp.x * -hd, z: inp.y * hd };
}
function updateControl(t, dt) {
  if (!t.human) { t.ctrl = null; return; }
  t.lock -= dt;
  const owner = ball.owner;
  if (S.state === 'restart' && S.restart && S.restart.team === t) { t.ctrl = S.restart.taker; return; }
  if (owner && owner.team === t && owner.role !== 'GK') { t.ctrl = owner; return; }
  let cur = t.ctrl;
  const bx = ball.x + ball.vx * 0.4, bz = ball.z + ball.vz * 0.4;
  let best = null, bd = 1e9;
  for (const q of t.players) { if (q.role === 'GK') continue; const d = Math.hypot(q.x - bx, q.z - bz); if (d < bd) { bd = d; best = q; } }
  if (!cur || cur.role === 'GK') { t.ctrl = best; return; }
  const cd = Math.hypot(cur.x - bx, cur.z - bz);
  if (best !== cur && (cd - bd > 3.2 || (t.lock <= 0 && cd - bd > 1.4))) { t.ctrl = best; t.lock = 0.7; }
}
function computeChasers() {
  for (const t of T) {
    const bx = ball.x + ball.vx * 0.35, bz = ball.z + ball.vz * 0.35;
    const c = t.players.filter((p) => p.role !== 'GK' && p !== t.ctrl && p !== ball.owner).map((p) => ({ p, d: Math.hypot(p.x - bx, p.z - bz) })).sort((a, b) => a.d - b.d);
    t.chaser = c[0] ? c[0].p : null; t.chaser2 = c[1] ? c[1].p : null;
    t.hasBall = !!(ball.owner && ball.owner.team === t);
  }
}

/* ───────────────────────── player movement ───────────────────────── */
function drive(p, dt, dirx, dirz, mag, sprint, sf) {
  const sp0 = Math.hypot(p.vx, p.vz);
  const sprinting = sprint && p.stam > 4 && mag > 0.1;
  const maxS = (sprinting ? 8.0 : 5.7) * p.pace * sf * (ball.owner === p ? 0.95 : 1) * (p.stun > 0 ? 0.35 : 1) * (p.tackleAnim > 0 ? 0 : 1);
  const tvx = dirx * maxS * mag, tvz = dirz * maxS * mag;
  let ax = tvx - p.vx, az = tvz - p.vz; const am = Math.hypot(ax, az), lim = (p.tackleAnim > 0 ? 3 : 20) * dt;
  if (am > lim) { ax = (ax / am) * lim; az = (az / am) * lim; }
  p.vx += ax; p.vz += az;
  if (sprinting && sp0 > 6) p.stam = Math.max(0, p.stam - 17 * dt); else p.stam = Math.min(100, p.stam + (sp0 < 3.5 ? 13 : 5) * dt);
}
function moveTo(p, dt, tx, tz, sprint, sf) {
  const dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz);
  if (d < 0.2) return drive(p, dt, 0, 0, 0, false, sf);
  drive(p, dt, dx / d, dz / d, Math.min(1, d / 2.2), sprint, sf);
}

function updatePlayer(p, dt) {
  const t = p.team;
  p.kickCd -= dt; p.stun -= dt; p.tackleCd -= dt; p.kickAnim -= dt; p.header -= dt; p.celebrate -= dt;
  if (p.tackleAnim > 0) { p.tackleAnim -= dt; if (!p.tackleDone && p.tackleAnim < 0.38) resolveTackle(p); }
  const idle = S.state === 'goal' || S.state === 'half' || S.state === 'full';
  const isTaker = S.state === 'restart' && S.restart && S.restart.taker === p;
  p.dive = 0;
  if (idle) { drive(p, dt, 0, 0, 0, false, 1); }
  else if (isTaker) { p.vx = p.vz = 0; if (t.human && t.ctrl === p && S.mode === 'match') humanActions(p, dt); }
  else if (S.state === 'restart' && S.restart.type === 'penalty' && p.role !== 'GK') { p.vx = p.vz = 0; }
  else if (t.human && t.ctrl === p && S.mode === 'match') humanUpdate(p, dt);
  else if (p.role === 'GK') gkUpdate(p, dt);
  else aiOutfield(p, dt);
  const sp = Math.hypot(p.vx, p.vz);
  if (!isTaker) { p.x += p.vx * dt; p.z += p.vz * dt; }
  p.x = clamp(p.x, -HW - 4, HW + 4); p.z = clamp(p.z, -HL - 4, HL + 4);
  if (sp > 0.6 && p.tackleAnim <= 0) p.face = turnTo(p.face, Math.atan2(p.vx, p.vz), (ball.owner === p ? 7 : 10) * dt);
  p.phase += sp * dt * 1.55;
}

function humanUpdate(p, dt) {
  const m = worldMove(), mag = Math.min(1, Math.hypot(m.x, m.z));
  if (mag > 0.12) drive(p, dt, m.x / mag, m.z / mag, mag, inp.sprint, 1); else drive(p, dt, 0, 0, 0, false, 1);
  humanActions(p, dt);
}
function humanActions(p, dt) {
  const m = worldMove(), mag = Math.min(1, Math.hypot(m.x, m.z));
  const owner = ball.owner === p;
  const fx = Math.sin(p.face), fz = Math.cos(p.face);
  const dx = mag > 0.25 ? m.x : fx, dz = mag > 0.25 ? m.z : fz;
  if (owner) {
    if (inp.passP) doPass(p, dx, dz, false, true);
    else if (inp.lobP) doPass(p, dx, dz, true, true);
    else {
      if (inp.shootHeld) S.charge = Math.min(1, S.charge + dt / 0.85);
      if (inp.shootR || (S.charge > 0 && !inp.shootHeld)) { doShoot(p, mag > 0.25 ? m.x : 0, Math.max(0.45, S.charge)); S.charge = 0; }
    }
  } else {
    S.charge = 0;
    if (inp.shootP) performTackle(p);
    if ((inp.passP || inp.lobP) && !(ball.owner && ball.owner.team === p.team)) switchPlayer(p.team);
  }
}
function switchPlayer(t) {
  const bx = ball.x + ball.vx * 0.4, bz = ball.z + ball.vz * 0.4;
  let best = null, bd = 1e9;
  for (const q of t.players) { if (q.role === 'GK' || q === t.ctrl) continue; const d = Math.hypot(q.x - bx, q.z - bz); if (d < bd) { bd = d; best = q; } }
  if (best) { t.ctrl = best; t.lock = 1.0; }
}

/* goalkeeper */
function gkUpdate(p, dt) {
  const t = p.team, gz = -t.dir * HL;
  if (ball.owner === p) { // holding the ball
    drive(p, dt, 0, 0, 0, false, 1); p.face = turnTo(p.face, t.dir > 0 ? 0 : Math.PI, 6 * dt);
    p.hold -= dt;
    if (p.hold <= 0 && S.state === 'play') {
      const r = bestPass(p, 0, t.dir, false);
      if (r.q) { const d = dist(p, r.q), sp = clamp(d * 0.75 + 4, 12, 27); kick(p, r.q.x - p.x, r.q.z - p.z, sp, clamp(4.9 * (d / sp) * 1.05, 3, 14)); }
      else kick(p, rnd(-0.4, 0.4), t.dir, 22, 8);
    }
    return;
  }
  let tx, tz, sprint = false, sf = 1.1;
  const nx = ball.x, nz = ball.z - gz, d = Math.hypot(nx, nz) || 1, k = clamp(d * 0.1, 1.1, 5.2);
  tx = clamp((nx / d) * k, -GW - 1.2, GW + 1.2); tz = gz + t.dir * Math.abs((nz / d) * k) + t.dir * 0.4;
  // loose ball in box → come out
  const inBox = Math.abs(ball.x) < BOX_W && Math.abs(ball.z - gz) < BOX_D;
  if (!ball.owner && inBox && Math.hypot(ball.vx, ball.vz) < 8) {
    let od = 1e9; for (const o of t.opp.players) od = Math.min(od, Math.hypot(o.x - ball.x, o.z - ball.z));
    if (Math.hypot(p.x - ball.x, p.z - ball.z) < od - 0.8) { tx = ball.x; tz = ball.z; sprint = true; }
  }
  // shot prediction
  const toGoal = ball.vz * -t.dir;
  if (!ball.owner && toGoal < -6 && Math.hypot(ball.vx, ball.vz) > 9) {
    const tt = (gz - ball.z) / ball.vz;
    if (tt > 0 && tt < 1.4) {
      const px = ball.x + ball.vx * tt;
      if (Math.abs(px) < GW + 2.2) {
        tx = clamp(px, -GW - 0.6, GW + 0.6); tz = gz + t.dir * 0.6; sf = 1.5; sprint = true;
        if (tt < 0.55 && Math.abs(px - p.x) > 1.0) p.dive = Math.sign(px - p.x);
      }
    }
  }
  moveTo(p, dt, tx, tz, sprint, sf);
  if (Math.hypot(p.vx, p.vz) < 0.8) p.face = turnTo(p.face, Math.atan2(ball.x - p.x, ball.z - p.z), 6 * dt);
}

/* outfield AI */
function aiOutfield(p, dt) {
  const t = p.team, o = t.opp, hp = homePos(p), owner = ball.owner;
  const sf = t.aiSpeed;
  if (owner === p) return carrier(p, dt);
  let tx = hp.x, tz = hp.z, sprint = false;
  const ownGz = -t.dir * HL;
  if (S.state === 'restart' && S.restart) {
    const r = S.restart;
    if (r.type === 'corner') {
      if (r.team === t) { if (p.role !== 'DEF') { tx = ((p.idx * 5) % 9 - 4) * 2.4; tz = t.dir * (HL - 9 - (p.idx % 3) * 2.2); } }
      else { tx = ((p.idx * 5) % 9 - 4) * 2.2; tz = ownGz + t.dir * (5 + (p.idx % 3) * 2.5); }
    } else if (r.type === 'throw' || r.type === 'freekick') { /* keep shape */ }
  } else if (owner && owner.team === t) {
    // support run
    tz = hp.z; tx = hp.x + Math.sin(S.t * 0.45 + p.idx) * 4;
    if (p.role === 'FWD') tz += t.dir * (4 + Math.sin(S.t * 0.7 + p.idx) * 3);
    const dd = Math.hypot(tx - owner.x, tz - owner.z);
    if (dd < 7) { tx += (tx - owner.x) / (dd || 1) * (7 - dd); tz += (tz - owner.z) / (dd || 1) * (7 - dd); }
    sprint = p.role === 'FWD' && Math.abs(tz - p.z) > 10;
  } else if (p === t.chaser && !(S.state === 'restart')) {
    if (owner) { // press carrier, stay goal-side
      const vx = 0 - owner.x, vz = ownGz - owner.z, L = Math.hypot(vx, vz) || 1;
      tx = owner.x + owner.vx * 0.3 + (vx / L) * 1.1; tz = owner.z + owner.vz * 0.3 + (vz / L) * 1.1;
      const dd = Math.hypot(owner.x - p.x, owner.z - p.z);
      sprint = dd > 4;
      if (dd < 1.7 && p.tackleCd <= 0 && Math.random() < t.tackle * dt * 2.6) performTackle(p);
    } else { tx = ball.x + ball.vx * 0.4; tz = ball.z + ball.vz * 0.4; sprint = Math.hypot(tx - p.x, tz - p.z) > 3; }
  } else if (p === t.chaser2 && owner && S.state !== 'restart' && Math.hypot(owner.x - p.x, owner.z - p.z) < 16) {
    const vx = 0 - owner.x, vz = ownGz - owner.z, L = Math.hypot(vx, vz) || 1;
    tx = owner.x + (vx / L) * 4.5; tz = owner.z + (vz / L) * 4.5; sprint = true;
  } else if (owner && S.state !== 'restart' && (p.role === 'DEF' || p.role === 'MID')) {
    // mark nearest attacker
    let mo = null, md = 14;
    for (const q of o.players) { if (q.role === 'GK' || q === owner) continue; const d = Math.hypot(q.x - hp.x, q.z - hp.z); if (d < md) { md = d; mo = q; } }
    if (mo) { tx = lerp(hp.x, mo.x + (0 - mo.x) * 0.15, 0.55); tz = lerp(hp.z, mo.z + (ownGz - mo.z) * 0.15, 0.55); }
  }
  if (S.state === 'restart' && S.restart && S.restart.team !== t && (S.restart.type === 'freekick' || S.restart.type === 'corner')) {
    const dd = Math.hypot(tx - S.restart.x, tz - S.restart.z);
    if (dd < 10) { const k = 10.2 / (dd || 1); tx = S.restart.x + (tx - S.restart.x) * k; tz = S.restart.z + (tz - S.restart.z) * k; }
  }
  moveTo(p, dt, tx, tz, sprint, sf);
}

function carrier(p, dt) {
  const t = p.team, gz = t.dir * HL;
  if (S.state === 'restart') return;
  p.think -= dt;
  const d = Math.hypot(p.x, gz - p.z), pressure = nearestOppDist(p);
  if (p.think <= 0) {
    p.think = t.react * rnd(0.7, 1.3);
    const inCone = Math.abs(p.x) < 24;
    if (d < 27 && inCone && Math.random() < (d < 12 ? 0.5 : d < 20 ? 0.22 : 0.07)) { doShoot(p, rnd(-0.8, 0.8), rnd(0.6, 0.95)); return; }
    if (pressure < 3.4 || Math.random() < 0.2) {
      const r = bestPass(p, 0, 0, false);
      if (r.q && r.score > (pressure < 2.4 ? -6 : 1.5)) { doPass(p, 0, 0, Math.random() < 0.18 && dist(p, r.q) > 18, false); return; }
    }
  }
  let tx = p.x * 0.5, tz = gz;
  let near = null, nd = 7;
  for (const o of t.opp.players) { const dz = (o.z - p.z) * t.dir; if (dz > 0 && dz < 7) { const dd = Math.hypot(o.x - p.x, o.z - p.z); if (dd < nd) { nd = dd; near = o; } } }
  if (near) tx = p.x + (p.x >= near.x ? 1 : -1) * 9;
  tx = clamp(tx, -HW + 3, HW - 3);
  moveTo(p, dt, tx, tz, pressure > 5 || d < 30, t.aiSpeed * 0.97);
}

/* ───────────────────────── ball physics ───────────────────────── */
function updateOwnerBall(dt) {
  const p = ball.owner;
  if (S.state === 'restart' && S.restart && S.restart.taker === p) {
    ball.x = S.restart.x; ball.z = S.restart.z; ball.y = S.restart.type === 'throw' ? 1.9 : 0.11; ball.vx = ball.vy = ball.vz = 0; return;
  }
  if (p.role === 'GK') { ball.x = p.x + Math.sin(p.face) * 0.35; ball.z = p.z + Math.cos(p.face) * 0.35; ball.y = 1.05; ball.vx = ball.vz = ball.vy = 0; return; }
  const off = 0.62 + 0.28 * Math.sin(p.phase * 2.0);
  ball.x = p.x + Math.sin(p.face) * off; ball.z = p.z + Math.cos(p.face) * off; ball.y = 0.11; ball.vx = p.vx; ball.vz = p.vz; ball.vy = 0;
}
function ballPhysics(dt) {
  if (ball.owner) return updateOwnerBall(dt);
  const b = ball, sub = 2, h = dt / sub;
  for (let s = 0; s < sub; s++) {
    b.vy -= 9.8 * h;
    const onG = b.y <= b.r + 0.02, sp = Math.hypot(b.vx, b.vz);
    if (!onG) {
      const k = Math.exp(-0.04 * h); b.vx *= k; b.vz *= k;
      if (b.spin) { const ax = -b.vz * b.spin * 0.1 * h, az = b.vx * b.spin * 0.1 * h; b.vx += ax; b.vz += az; }
    } else {
      const k = Math.exp(-(b.inNet ? 3 : 0.65) * h); b.vx *= k; b.vz *= k; b.spin *= 0.98; if (sp < 0.1) { b.vx = 0; b.vz = 0; }
    }
    b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h;
    if (b.y < b.r) { b.y = b.r; if (b.vy < -1.3) { b.vy = -b.vy * 0.62; b.vx *= 0.92; b.vz *= 0.92; b.spin *= 0.5; } else b.vy = 0; }
    // posts
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const px = sx * GW, pz = sz * HL, dx = b.x - px, dz = b.z - pz, d = Math.hypot(dx, dz);
      if (d < b.r + 0.07 && b.y < GH + 0.05 && d > 1e-4) {
        const nx = dx / d, nz = dz / d, vn = b.vx * nx + b.vz * nz;
        if (vn < 0) { b.vx -= 1.7 * vn * nx; b.vz -= 1.7 * vn * nz; b.vx *= 0.85; b.vz *= 0.85; }
        b.x = px + nx * (b.r + 0.071); b.z = pz + nz * (b.r + 0.071);
      }
    }
    for (const sz of [-1, 1]) { // crossbar
      if (Math.abs(b.x) < GW + 0.05 && Math.abs(b.z - sz * HL) < b.r + 0.06 && Math.abs(b.y - GH) < b.r + 0.06) {
        if (Math.abs(b.y - GH) > 0.07) { b.vy = -b.vy * 0.55; b.y = GH + Math.sign(b.y - GH) * (b.r + 0.07); b.vz *= 0.7; }
        else { b.vz = -b.vz * 0.55; b.z = sz * HL + Math.sign(b.z - sz * HL || 1) * (b.r + 0.07); }
      }
    }
    if (b.inNet) { // net constraints
      const sz = Math.sign(b.z) || 1;
      if (Math.abs(b.z) > HL + 2.4) { b.z = sz * (HL + 2.4); b.vz *= -0.1; b.vx *= 0.5; }
      if (Math.abs(b.x) > GW - 0.1 && Math.abs(b.z) > HL) { b.x = Math.sign(b.x) * (GW - 0.1); b.vx *= -0.2; }
      if (b.y > GH - 0.05 && Math.abs(b.z) > HL) { b.y = GH - 0.05; b.vy = -Math.abs(b.vy) * 0.1; }
      if (Math.abs(b.z) < HL && b.vz * sz < 0) b.inNet = true;
    }
  }
}
function ballInteract(dt) {
  if (ball.owner || S.state !== 'play') return;
  let best = null, bd = 1e9;
  for (const p of ALL) {
    if (p.role === 'GK' || p.kickCd > 0 || p.stun > 0) continue;
    const d = Math.hypot(ball.x - p.x, ball.z - p.z), reach = p.tackleAnim > 0 ? 1.3 : 0.95;
    if (d < reach && ball.y < 2.2 && d < bd) { bd = d; best = p; }
  }
  if (best) touchBall(best);
  for (const t of T) gkSave(t.players[0]);
}
function touchBall(p) {
  const sp = Math.hypot(ball.vx - p.vx, ball.vz - p.vz, ball.vy * 0.5);
  if (ball.y > 1.3) return header(p);
  if (sp > 24 && Math.random() < 0.45) { ball.vx = ball.vx * 0.35 + p.vx * 0.5 + rnd(-3, 3); ball.vz = ball.vz * 0.35 + p.vz * 0.5 + rnd(-3, 3); ball.vy = rnd(1, 4); ball.last = p; p.kickCd = 0.3; return; }
  takeBall(p);
}
function header(p) {
  const t = p.team; let dx, dz;
  const m = worldMove();
  if (t.human && t.ctrl === p && Math.hypot(m.x, m.z) > 0.3) { dx = m.x; dz = m.z; }
  else if (Math.hypot(p.x, t.dir * HL - p.z) < 24) { dx = rnd(-3, 3) - p.x; dz = t.dir * HL - p.z; }
  else { dx = rnd(-0.6, 0.6); dz = t.dir; }
  const L = Math.hypot(dx, dz) || 1, sp = rnd(9, 15);
  ball.vx = (dx / L) * sp; ball.vz = (dz / L) * sp; ball.vy = rnd(2, 4.5); ball.last = p; ball.shot++; p.kickCd = 0.5; p.header = 0.3;
  sfxKick(0.4);
}
function gkSave(g) {
  if (ball.owner || g.kickCd > 0 || g.stun > 0) return;
  const d3 = Math.hypot(ball.x - g.x, (Math.min(ball.y, 2.3) - 1.0) * 0.8, ball.z - g.z);
  const reach = g.dive !== 0 ? 2.5 : 1.3;
  if (d3 > reach) return;
  const sp = Math.hypot(ball.vx, ball.vz, ball.vy);
  if (sp >= 9) { if (g.checkedShot === ball.shot) return; g.checkedShot = ball.shot; }
  const prob = sp < 9 ? 0.98 : clamp(g.team.gk - (sp - 12) * 0.012, 0.12, 0.97);
  if (Math.random() < prob) {
    if (sp < 17 || Math.random() < 0.55) { takeBall(g); }
    else { ball.vx = -ball.vx * 0.2 + rnd(-4, 4); ball.vz = -ball.vz * 0.3; ball.vy = rnd(2, 5); ball.last = g; g.kickCd = 0.6; ball.shot++; }
  }
}

/* ───────────────────────── rules ───────────────────────── */
function checkRules() {
  if (S.state !== 'play') return;
  const b = ball, e = b.r;
  // goal
  if (Math.abs(b.z) > HL + e && Math.abs(b.x) < GW && b.y < GH) { return goal(Math.sign(b.z)); }
  if (Math.abs(b.z) > HL + e) {
    const sz = Math.sign(b.z), lt = b.last ? b.last.team : null;
    const defTeam = T.find((t) => t.dir === -sz), atkTeam = defTeam.opp;
    if (lt === defTeam) setupRestart('corner', atkTeam, Math.sign(b.x || 1) * (HW - 0.4), sz * (HL - 0.4));
    else setupRestart('goalkick', defTeam, 0, sz * (HL - 5.5));
    return;
  }
  if (Math.abs(b.x) > HW + e) {
    const lt = b.last ? b.last.team : T[1];
    setupRestart('throw', lt.opp, Math.sign(b.x) * HW, clamp(b.z, -HL + 3, HL - 3));
  }
}
function goal(sz) {
  const st = T.find((t) => t.dir === sz); st.score++;
  S.state = 'goal'; S.goalT = 4.4; ball.inNet = true; S.concede = st.opp;
  S.scorer = ball.last && ball.last.team === st ? ball.last : st.players[9];
  banner('GOOOOL!', 3600); sfxWhistle(false); sfxRoar();
  for (const p of st.players) p.celebrate = rnd(2.5, 4);
  S.scorer.face = st.dir > 0 ? Math.PI : 0; S.scorer.vx = S.scorer.vz = 0;
  updateHud(true);
}
function endHalf() {
  S.state = 'half'; S.goalT = 3.2; sfxWhistle(true);
  banner(S.half === 1 ? 'XAGAAGA 1AAD' : 'DHAMMAAD', 3000);
  if (S.half === 2) { S.state = 'full'; S.goalT = 2.5; }
}

/* ───────────────────────── main update ───────────────────────── */
function update(dt) {
  S.t += dt;
  computeChasers();
  for (const t of T) updateControl(t, dt);
  if (S.state === 'restart') restartUpdate(dt);
  for (const p of ALL) updatePlayer(p, dt);
  // separation
  for (let i = 0; i < ALL.length; i++) for (let j = i + 1; j < ALL.length; j++) {
    const a = ALL[i], c = ALL[j], dx = c.x - a.x, dz = c.z - a.z, d2 = dx * dx + dz * dz;
    if (d2 < 0.64 && d2 > 1e-6) {
      if (S.state === 'restart' && (S.restart.taker === a || S.restart.taker === c)) continue;
      const d = Math.sqrt(d2), push = (0.8 - d) * 0.5, nx = dx / d, nz = dz / d;
      a.x -= nx * push; a.z -= nz * push; c.x += nx * push; c.z += nz * push;
    }
  }
  ballPhysics(dt);
  ballInteract(dt);
  if (S.state === 'play') {
    S.time += dt;
    if (S.time >= S.halfLen) {
      if (S.mode === 'menu') { S.time = 0; } else endHalf();
    }
    checkRules();
  } else if (S.state === 'goal') {
    S.goalT -= dt;
    if (S.goalT <= 0) setupRestart('kickoff', S.concede, 0, 0);
  } else if (S.state === 'half' || S.state === 'full') {
    S.goalT -= dt;
    if (S.goalT <= 0) {
      if (S.state === 'half') {
        S.half = 2; S.time = 0; for (const t of T) t.dir = -t.dir; S.homeDir = T[0].dir;
        for (const p of ALL) p.face = p.team.dir > 0 ? 0 : Math.PI;
        setupRestart('kickoff', T[1], 0, 0); S.snapCam = true;
      } else if (S.mode === 'match') finishMatch();
      else { S.half = 1; S.time = 0; }
    }
  }
  if (AC && crowd && S.state === 'play') {
    const gd = Math.min(Math.abs(ball.z - T[0].dir * HL), Math.abs(ball.z + T[0].dir * HL));
    crowd.gain.setTargetAtTime(0.1 + clamp((30 - gd) / 30, 0, 1) * 0.1, AC.currentTime, 0.4);
  }
}

/* ───────────────────────── rendering sync ───────────────────────── */
function syncMeshes(dt) {
  for (const p of ALL) {
    const m = p.mesh, pr = p.parts, sp = Math.hypot(p.vx, p.vz);
    m.position.set(p.x, 0, p.z); m.rotation.y = p.face;
    p.blob.position.set(p.x, 0.025, p.z);
    const sw = Math.min(1, sp / 6) * 0.95, ph = Math.sin(p.phase);
    pr.legL.rotation.x = ph * sw; pr.legR.rotation.x = -ph * sw;
    pr.armL.rotation.x = -ph * sw * 0.8; pr.armR.rotation.x = ph * sw * 0.8;
    pr.armL.rotation.z = 0.08; pr.armR.rotation.z = -0.08;
    pr.rig.rotation.set(Math.min(sp / 9, 1) * 0.22, 0, 0); pr.rig.position.y = 0;
    if (p.kickAnim > 0) { const k = Math.sin((1 - p.kickAnim / 0.3) * Math.PI); pr.legR.rotation.x = -k * 1.45; pr.armL.rotation.x = k * 0.6; }
    if (p.tackleAnim > 0) { const k = Math.min(1, (0.5 - p.tackleAnim) * 8) * Math.min(1, p.tackleAnim * 6); pr.rig.rotation.x = -1.25 * k; pr.rig.position.y = 0.28 * k; pr.legR.rotation.x = -0.3 * k; pr.legL.rotation.x = 0.2 * k; }
    if (p.header > 0) { pr.rig.position.y = Math.sin((1 - p.header / 0.3) * Math.PI) * 0.4; pr.rig.rotation.x = -0.25; }
    if (p.dive !== 0 || p.diveAmt) {
      p.diveAmt = lerp(p.diveAmt, p.dive, Math.min(1, dt * 12));
      const lx = Math.cos(p.face), lz = -Math.sin(p.face);
      void lx; void lz;
      pr.rig.rotation.z = -p.diveAmt * 1.25 * Math.sign(Math.cos(p.face) || 1); pr.rig.position.y = Math.abs(p.diveAmt) * 0.45;
      pr.armL.rotation.z = 2.8 * Math.abs(p.diveAmt); pr.armR.rotation.z = -2.8 * Math.abs(p.diveAmt);
      if (Math.abs(p.diveAmt) < 0.01) p.diveAmt = 0;
    }
    if (p.celebrate > 0) { pr.armL.rotation.x = 0; pr.armR.rotation.x = 0; pr.armL.rotation.z = 2.7; pr.armR.rotation.z = -2.7; pr.rig.position.y = Math.abs(Math.sin(S.t * 8 + p.idx)) * 0.25; }
  }
  // ball
  ball.mesh.position.set(ball.x, ball.y, ball.z);
  ball.mesh.rotation.x += ball.vz * dt / ball.r; ball.mesh.rotation.z -= ball.vx * dt / ball.r;
  ball.shadow.position.set(ball.x, 0.025, ball.z);
  ball.shadow.scale.setScalar(clamp(1 + ball.y * 0.2, 1, 2.2) * (SHADOWS ? 0.0001 : 1));
  // indicator
  const c = S.mode === 'match' ? T[0].ctrl : null;
  world.ring.visible = world.arrow.visible = !!c;
  if (c) { world.ring.position.set(c.x, 0.03, c.z); world.arrow.position.set(c.x, 2.35 + Math.sin(S.t * 6) * 0.08, c.z); world.arrow.rotation.y = S.t * 3; }
}

function updateCamera(dt) {
  if (S.mode === 'menu' && S.menuOrbit) {
    cam.orbit += dt * 0.08;
    camera.position.set(Math.sin(cam.orbit) * 72, 26, Math.cos(cam.orbit) * 80);
    camera.lookAt(0, 0, 0); return;
  }
  const hd = S.homeDir;
  let tx = ball.x + ball.vx * 0.25, tz = ball.z + ball.vz * 0.25;
  if (ball.owner) { tx = ball.owner.x; tz = ball.owner.z; }
  tz = clamp(tz, -HL + 8, HL - 8) + hd * 5; tx = clamp(tx, -HW + 8, HW - 8);
  const k = Math.min(1, dt * 3.2);
  cam.fx = lerp(cam.fx, tx, k); cam.fz = lerp(cam.fz, tz, k);
  if (S.state === 'goal' && S.scorer && S.goalT < 3.6) {
    const s = S.scorer;
    camera.position.x = lerp(camera.position.x, s.x + 6, dt * 2.2); camera.position.y = lerp(camera.position.y, 3.2, dt * 2.2); camera.position.z = lerp(camera.position.z, s.z - s.team.dir * 9, dt * 2.2);
    camera.lookAt(s.x, 1.5, s.z); return;
  }
  if (S.snapCam) { S.snapCam = false; camera.position.set(cam.fx * 0.55, 24, cam.fz - hd * 31); }
  const aspect = innerWidth / innerHeight;
  const height = 24 + (aspect < 1.5 ? 4 : 0), back = 31;
  const px = cam.fx * 0.55, py = height, pz = cam.fz - hd * back;
  camera.position.x = lerp(camera.position.x || px, px, 0.2); camera.position.y = lerp(camera.position.y || py, py, 0.1); camera.position.z = lerp(camera.position.z || pz, pz, 0.2);
  camera.lookAt(cam.fx * 0.85, 0, cam.fz + hd * 3);
  world.sun.position.set(cam.fx - 30, 60, cam.fz + 35); world.sun.target.position.set(cam.fx, 0, cam.fz);
}

/* ───────────────────────── HUD ───────────────────────── */
let bannerTimer = 0;
function banner(txt, ms = 1500) {
  const b = $('#banner'); b.textContent = txt; b.classList.add('on');
  clearTimeout(bannerTimer); bannerTimer = setTimeout(() => b.classList.remove('on'), ms);
}
function fmtClock() {
  const sec = ((S.half - 1) * 45 * 60) + (S.time / S.halfLen) * 45 * 60;
  const m = Math.min(S.half === 1 ? 45 : 90, Math.floor(sec / 60)), s = Math.floor(sec % 60);
  return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
}
function updateHud(force) {
  $('#hs').textContent = T[0].score; $('#as').textContent = T[1].score;
  $('#clk').textContent = fmtClock(); $('#hf').textContent = S.half === 1 ? '1H' : '2H';
  if (force || true) { const c = T[0].ctrl; $('#stam i').style.width = (c ? c.stam : 100) + '%'; }
  const pb = $('#pbar'); pb.classList.toggle('on', S.charge > 0); $('#pbar i').style.width = S.charge * 100 + '%';
  // context labels
  const attack = T[0].ctrl && ball.owner === T[0].ctrl;
  $('#bPass').textContent = attack ? 'BAAS' : 'BEDDEL';
  $('#bShoot').textContent = attack ? 'LAAD' : 'TACKLE';
}
const mini = $('#mini'), mc = mini.getContext('2d');
function drawMini() {
  const W = mini.width, H = mini.height, hd = S.homeDir;
  mc.clearRect(0, 0, W, H);
  const px = (x) => ((-x * -hd + HW) / (2 * HW)) * W, pz = (z) => ((hd < 0 ? z + HL : HL - z) / (2 * HL)) * H;
  const mx = (x) => (((hd < 0 ? x : -x) + HW) / (2 * HW)) * W;
  void px;
  mc.strokeStyle = 'rgba(255,255,255,.5)'; mc.lineWidth = 1; mc.strokeRect(1, 1, W - 2, H - 2);
  mc.beginPath(); mc.moveTo(0, H / 2); mc.lineTo(W, H / 2); mc.stroke();
  for (const p of ALL) { mc.fillStyle = p.team.kit.shirt; mc.beginPath(); mc.arc(mx(p.x), pz(p.z), p.role === 'GK' ? 2.2 : 2.6, 0, 7); mc.fill(); mc.strokeStyle = '#000a'; mc.stroke(); }
  mc.fillStyle = '#fff'; mc.beginPath(); mc.arc(mx(ball.x), pz(ball.z), 2.2, 0, 7); mc.fill();
  const c = S.mode === 'match' ? T[0].ctrl : null; if (c) { mc.strokeStyle = '#ffd24a'; mc.lineWidth = 2; mc.beginPath(); mc.arc(mx(c.x), pz(c.z), 4.5, 0, 7); mc.stroke(); }
}

/* ───────────────────────── UI / input wiring ───────────────────────── */
let selHome = 0, selAway = 1;
function buildMenu() {
  for (const [id, key] of [['#tHome', 'home'], ['#tAway', 'away']]) {
    const box = $(id); box.innerHTML = '';
    TEAMS.forEach((t, i) => {
      const d = document.createElement('div'); d.className = 'team' + ((key === 'home' ? selHome : selAway) === i ? ' sel' : '');
      d.innerHTML = `<span class="kit" style="background:linear-gradient(180deg,${t.shirt} 60%,${t.shorts} 60%)"></span>${t.name}`;
      d.onclick = () => { if (key === 'home') selHome = i; else selAway = i; buildMenu(); };
      box.appendChild(d);
    });
  }
}
function seg(id, cb) {
  const el = $(id);
  el.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => { el.querySelectorAll('button').forEach((x) => x.classList.remove('sel')); b.classList.add('sel'); cb(+b.dataset.v); }));
}
function startDemo() {
  buildTeams((Math.random() * 6) | 0, (Math.random() * 6) | 0);
  S.mode = 'menu'; S.menuOrbit = true; S.half = 1; S.time = 0; S.homeDir = T[0].dir;
  setupRestart('kickoff', T[1], 0, 0); $('#hud').classList.add('hidden');
}
function startMatch() {
  audioInit();
  buildTeams(selHome, selAway);
  T[0].human = true;
  S.mode = 'match'; S.menuOrbit = false; S.half = 1; S.time = 0; S.homeDir = T[0].dir; S.charge = 0;
  camera.position.set(0, 24, 40); cam.fx = 0; cam.fz = 0;
  $('#menu').classList.add('hidden'); $('#over').classList.add('hidden'); $('#pause').classList.add('hidden'); $('#hud').classList.remove('hidden');
  $('#hn').textContent = T[0].kit.short; $('#an').textContent = T[1].kit.short;
  $('#hc').style.background = T[0].kit.shirt; $('#ac').style.background = T[1].kit.shirt;
  setupRestart('kickoff', T[0], 0, 0);
  banner('KICK OFF', 1500); updateHud(true);
}
function finishMatch() {
  S.mode = 'over'; $('#hud').classList.add('hidden');
  $('#final').textContent = T[0].score + ' - ' + T[1].score;
  const r = T[0].score > T[1].score ? 'Guul! 🏆' : T[0].score < T[1].score ? 'Guuldarro' : 'Barbaar';
  $('#fname').textContent = `${T[0].kit.name} vs ${T[1].kit.name} · ${r}`;
  $('#over').classList.remove('hidden');
}
function toMenu() { $('#over').classList.add('hidden'); $('#pause').classList.add('hidden'); $('#menu').classList.remove('hidden'); startDemo(); }
function setPause(v) {
  if (S.mode !== 'match' && S.mode !== 'paused') return;
  S.mode = v ? 'paused' : 'match'; $('#pause').classList.toggle('hidden', !v);
}

function bindButton(id, down, up) {
  const el = $(id);
  const d = (e) => { e.preventDefault(); el.classList.add('down'); try { el.setPointerCapture(e.pointerId); } catch (x) { /* */ } audioInit(); down(); };
  const u = (e) => { e.preventDefault(); el.classList.remove('down'); if (up) up(); };
  el.addEventListener('pointerdown', d); el.addEventListener('pointerup', u); el.addEventListener('pointercancel', u); el.addEventListener('lostpointercapture', u);
}
function wireInput() {
  bindButton('#bShoot', () => { inp.shootHeld = true; inp.shootP = true; }, () => { if (inp.shootHeld) inp.shootR = true; inp.shootHeld = false; });
  bindButton('#bPass', () => { inp.passP = true; });
  bindButton('#bLob', () => { inp.lobP = true; });
  bindButton('#bSprint', () => { inp.sprint = true; }, () => { inp.sprint = false; });
  $('#bPause').addEventListener('click', () => setPause(true));
  $('#bResume').addEventListener('click', () => setPause(false));
  $('#bQuit').addEventListener('click', toMenu);
  $('#bAgain').addEventListener('click', startMatch);
  $('#bMenu2').addEventListener('click', toMenu);
  $('#bStart').addEventListener('click', startMatch);
  // joystick
  const zone = $('#stickzone'), stick = $('#stick'), knob = $('#knob'); let sid = null, ox = 0, oy = 0; const R = 52;
  zone.addEventListener('pointerdown', (e) => { e.preventDefault(); audioInit(); sid = e.pointerId; zone.setPointerCapture(sid); ox = e.clientX; oy = e.clientY; stick.style.display = 'block'; stick.style.left = ox - 64 - zone.getBoundingClientRect().left + 'px'; stick.style.top = oy - 64 - zone.getBoundingClientRect().top + 'px'; knob.style.transform = 'translate(0,0)'; });
  zone.addEventListener('pointermove', (e) => {
    if (e.pointerId !== sid) return; let dx = e.clientX - ox, dy = e.clientY - oy; const d = Math.hypot(dx, dy);
    if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
    knob.style.transform = `translate(${dx}px,${dy}px)`; inp.x = dx / R; inp.y = -dy / R;
    inp.sprint = inp.sprint || false;
  });
  const end = (e) => { if (e.pointerId !== sid) return; sid = null; stick.style.display = 'none'; inp.x = inp.y = 0; };
  zone.addEventListener('pointerup', end); zone.addEventListener('pointercancel', end);
  // keyboard
  const keys = {};
  const kmap = () => { inp.x = (keys.arrowright || keys.d ? 1 : 0) - (keys.arrowleft || keys.a ? 1 : 0); inp.y = (keys.arrowup || keys.w ? 1 : 0) - (keys.arrowdown || keys.s ? 1 : 0); const l = Math.hypot(inp.x, inp.y); if (l > 1) { inp.x /= l; inp.y /= l; } inp.sprint = !!keys.shift; };
  addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase(); if (e.repeat) return; audioInit();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
    keys[k] = true; kmap();
    if (k === ' ' || k === 'j') { inp.shootHeld = true; inp.shootP = true; }
    if (k === 'e' || k === 'k') inp.passP = true;
    if (k === 'q' || k === 'l') inp.lobP = true;
    if (k === 'p' || k === 'escape') setPause(S.mode === 'match');
  });
  addEventListener('keyup', (e) => {
    const k = e.key.toLowerCase(); keys[k] = false; kmap();
    if (k === ' ' || k === 'j') { if (inp.shootHeld) inp.shootR = true; inp.shootHeld = false; }
  });
  addEventListener('blur', () => { for (const k in keys) keys[k] = false; kmap(); if (S.mode === 'match') setPause(true); });
  if (!IS_TOUCH) $('#touch').style.display = 'none';
}
function resize() {
  const w = innerWidth, h = innerHeight; renderer.setSize(w, h, false); camera.aspect = w / h;
  camera.fov = w / h < 1.5 ? 52 : 42; camera.updateProjectionMatrix();
}

/* ───────────────────────── boot ───────────────────────── */
initGeos(); buildWorld(); buildBall(); wireInput(); buildMenu();
seg('#sDiff', (v) => { S.diff = v; if (T.length) applyDiff(); });
seg('#sLen', (v) => { S.halfLen = v; });
addEventListener('resize', resize); resize();
startDemo();

let last = performance.now(), acc = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (S.mode !== 'paused' && S.mode !== 'over') { acc += dt; while (acc >= 1 / 60) { update(1 / 60); acc -= 1 / 60; } }
  syncMeshes(dt); updateCamera(dt);
  S.hudT += dt; if (S.hudT > 0.12 && S.mode === 'match') { S.hudT = 0; updateHud(); }
  S.miniT += dt; if (S.miniT > 0.1 && S.mode === 'match') { S.miniT = 0; drawMini(); }
  inp.passP = inp.lobP = inp.shootP = inp.shootR = false;
  renderer.render(scene, camera);
}
requestAnimationFrame(frame);

if (TEST) window.__fb = { S, ball, T, update, inp, startMatch, selHome: () => selHome, get ALL() { return ALL; } };
