// Copies three.js (installed from npm) into www/vendor so the game works fully offline inside the APK.
import { copyFileSync, mkdirSync, existsSync } from 'node:fs';
const src = 'node_modules/three/build/three.module.js';
if (!existsSync(src)) { console.error('Run "npm install" first.'); process.exit(1); }
mkdirSync('www/vendor', { recursive: true });
copyFileSync(src, 'www/vendor/three.module.js');
console.log('three.module.js copied to www/vendor');
