# FOOTBALL 3D PRO — sida loo helo APK-ga

Ciyaartu waa **11 vs 11**: xeerar (throw-in, goal kick, corner, free kick, penalty, foul), tackle, goalkeeper AI,
saddex heer oo AI ah, labo qeybood, minimap, codad (dhagaystayaal, foori, laad), iyo kontoroolo taabasho.
Kooxaha waa **khayaali** (ma jiraan magacyo/ciyaaryaano rukhsad leh sida FC26 / eFootball).

## Habka 1 — GitHub (ugu fudud, kombiyuutar looma baahna Android Studio)
1. Samee akoon GitHub oo samee repository cusub (private ama public).
2. Soo geli (upload) **dhammaan faylasha** folder-kan (oo ay ku jiraan `.github/`).
3. Tag **Actions** → "Build Android APK" → **Run workflow**. Sug ~5-8 daqiiqo.
4. Marka uu dhammaado, gudaha run-ka ka soo dag **football-3d-pro-apk** → `app-debug.apk`.
5. Taleefanka ku rakib (u ogolow "Install unknown apps").

## Habka 2 — Kombiyuutarkaaga (Node 20 + JDK 17 + Android SDK)
```
npm install
npm run android:add
npm run apk
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## Tijaabi browser-ka (PC)
```
npm install
npm run dev     # → http://localhost:8080
```

## Kontoroolada
| Taabasho | Kiiboor | Shaqada |
|---|---|---|
| Joystick bidix | WASD / fallaaro | Dhaqdhaqaaq |
| BAAS | E / K | Baas dhul ah (difaac: beddel ciyaaryahan) |
| LAAD | Space / J (hay = xoog) | Toogasho (difaac: TACKLE) |
| KOR | Q / L | Baas dheer / cross |
| ORO | Shift | Orod (stamina ayaa dhammaata) |
| ❚❚ | P | Nasasho |

## Xadadka (daacadnimo)
Tani waa ciyaar 3D oo si fiican u dhisan, **laakiin** ma aha FC26 ama eFootball: ma jiraan wajiyo la sawiray, kooxo/liisanno rasmi ah,
animation motion-capture, online multiplayer ama career mode. Waxaa lagu sii kordhin karaa (offside, kaadhadh, replay, kooxo la beddeli karo, online).
